// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
//
#include <iomanip>
#include <iostream>
#include <cstring> // Added to use strnlen for safer string handling

int main()
{
    std::cout << "Buffer Overflow Example" << std::endl;

    // TODO: The user can type more than 20 characters and overflow the buffer, resulting in account_number being replaced -
    //  even though it is a constant and the compiler buffer overflow checks are on.
    //  You need to modify this method to prevent buffer overflow without changing the account_number
    //  variable, and its position in the declaration. It must always be directly before the variable used for input.
    //  You must notify the user if they entered too much data.

    const std::string account_number = "CharlieBrown42"; 

    char user_input[20]; // This buffer is where the user will input their string

    std::cout << "Enter a value (max 19 characters): "; // Inform user of limit
    std::cin.getline(user_input, sizeof(user_input)); // Using getline to limit input to 19 characters (leaving space for null terminator)

    // Check if input exceeds the limit, notify the user if it does
    if (std::cin.fail()) {
        std::cin.clear(); // Clear error state caused by overflow
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); // Ignore remaining characters in the input buffer
        std::cout << "You entered too many characters. The input was truncated to 19 characters." << std::endl;
    }

    std::cout << "You entered: " << user_input << std::endl; // Output the safely captured input
    std::cout << "Account Number = " << account_number << std::endl; // Account number remains unchanged
}


// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu