#include <cassert>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <ctime>
#include <string>  // Ensure the string library is included

/// <summary>
/// encrypt or decrypt a source string using the provided key
/// </summary>
/// <param name="source">input string to process</param>
/// <param name="key">key to use in encryption / decryption</param>
/// <returns>transformed string</returns>
std::string encrypt_decrypt(const std::string& source, const std::string& key)
{
    const auto key_length = key.length();  // Get the length of the key
    const auto source_length = source.length();  // Get the length of the source string

    assert(key_length > 0);
    assert(source_length > 0);

    std::string output = source;

    for (size_t i = 0; i < source_length; ++i)
    {
        // XOR each character of the source with the key (mod key length)
        output[i] = source[i] ^ key[i % key_length];
    }

    assert(output.length() == source_length);  // Ensure the output length matches the source length
    return output;
}

/// <summary>
/// Reads the contents of the file into a string
/// </summary>
/// <param name="filename">The file to read from</param>
/// <returns>The string contents of the file</returns>
std::string read_file(const std::string& filename)
{
    std::ifstream file(filename);  // Open file for reading
    std::stringstream buffer;

    if (file)
    {
        buffer << file.rdbuf();  // Read the entire file into the buffer
        return buffer.str();  // Return the contents as a string
    }
    else
    {
        std::cerr << "Error: Unable to open file " << filename << std::endl;
        return "";
    }
}

/// <summary>
/// Extracts the student's name from the string data
/// </summary>
/// <param name="string_data">The string containing the student's name</param>
/// <returns>The student's name</returns>
std::string get_student_name(const std::string& string_data)
{
    std::string student_name;
    size_t pos = string_data.find('\n');  // Find the first newline character

    if (pos != std::string::npos)
    {
        student_name = string_data.substr(0, pos);  // Extract the substring as the student name
    }

    return student_name;
}

/// <summary>
/// Saves data to a file with the provided format
/// </summary>
/// <param name="filename">The name of the file to save to</param>
/// <param name="student_name">The student's name</param>
/// <param name="key">The encryption key used</param>
/// <param name="data">The data to save</param>
void save_data_file(const std::string& filename, const std::string& student_name, const std::string& key, const std::string& data)
{
    std::ofstream file(filename);  // Open the file for writing

    if (file)
    {
        // Get the current time and format it as yyyy-mm-dd
        std::time_t now = std::time(nullptr);
        std::tm time_info;  // Create a `std::tm` structure
        localtime_s(&time_info, &now);  // Use the secure version of localtime

        char time_buffer[11];
        std::strftime(time_buffer, sizeof(time_buffer), "%Y-%m-%d", &time_info);  // Format the time

        // Write the formatted data to the file
        file << student_name << "\n";
        file << time_buffer << "\n";
        file << key << "\n";
        file << data;  // Save the actual data
    }
    else
    {
        std::cerr << "Error: Unable to save file " << filename << std::endl;
    }
}

int main()
{
    std::cout << "Encryption Decryption Test!" << std::endl;

    // Use just the file name, assuming it will be found in the working directory
    const std::string file_name = "inputdatafile.txt";
    const std::string encrypted_file_name = "encrypteddatafile.txt";
    const std::string decrypted_file_name = "decrypteddatafile.txt";
    const std::string key = "password";

    // Read the input file
    const std::string source_string = read_file(file_name);

    // Check if file read was successful
    if (source_string.empty()) {
        std::cerr << "Error: Could not read input file!" << std::endl;
        return 1;  // Exit the program if file reading failed
    }

    // Encrypt the source string
    const std::string encrypted_string = encrypt_decrypt(source_string, key);

    // Save the encrypted data to a file
    save_data_file(encrypted_file_name, get_student_name(source_string), key, encrypted_string);

    // Decrypt the encrypted string
    const std::string decrypted_string = encrypt_decrypt(encrypted_string, key);

    // Save the decrypted data to a file
    save_data_file(decrypted_file_name, get_student_name(source_string), key, decrypted_string);

    std::cout << "Read File: " << file_name << " - Encrypted To: " << encrypted_file_name << " - Decrypted To: " << decrypted_file_name << std::endl;

    return 0;  // Return success
}
